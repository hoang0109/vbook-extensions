let BASE_URL = 'https://metruyencv.biz';
let BASE_URL2 = 'https://metruyencv.com';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}